export default class SampleEvent {

    public static readonly Sample_BLOOD_UPDATE = "Sample_BLOOD_UPDATE";
    public static readonly Sample_CARS_NUM_UPDATE = "Sample_CARS_NUM_UPDATE";
    public static readonly Sample_SCORE_UPDATE = "Sample_SCORE_UPDATE";
    public static readonly Sample_GOLD_UPDATE = "Sample_GOLD_UPDATE";
    public static readonly Sample_SKIN_UPDATE = "Sample_SKIN_UPDATE";
    public static readonly Sample_COLOR_UPDATE = "Sample_COLOR_UPDATE";
    public static readonly Sample_SCORE_TIPS = "Sample_SCORE_TIPS";
    public static readonly Sample_PLAYER_EVENT = "Sample_PLAYER_EVENT";

}