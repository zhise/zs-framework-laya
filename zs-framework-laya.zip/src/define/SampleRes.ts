export default class SampleRes {
            
    public static readonly Sound_Click = "sound/buttonClick.wav";

    public static readonly Sprite3d_Block = "block";
    public static readonly Sprite3d_Gold = "ef_jinbi_01";
}