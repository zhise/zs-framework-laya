export default class SceneLogic extends Laya.Script {
    
    constructor() { super(); }
    
    onEnable(): void {
    }

    onDisable(): void {
    }

    wakeup(): void {

    }

    sleep(): void {
    }
}